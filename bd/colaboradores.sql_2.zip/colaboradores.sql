-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: 29-Abr-2017 às 00:42
-- Versão do servidor: 5.6.35
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bd_integrado`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `colaboradores`
--

CREATE TABLE `colaboradores` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(80) NOT NULL,
  `email` varchar(80) NOT NULL,
  `senha` varchar(80) NOT NULL,
  `senhaConf` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `colaboradores`
--

INSERT INTO `colaboradores` (`id`, `nome`, `email`, `senha`, `senhaConf`) VALUES
(1, 'Rafael', 'rafael@labwp.com', '123', '123'),
(2, 'Rafael', 'teste@teste', '', ''),
(3, 'Bruna', 'teste@teste', '12', '12'),
(4, 'Bruna', 'teste@teste', '12', '12'),
(5, 'Rafael', 'teste@teste', '12', '22'),
(6, 'RAFAEL', 'TESTE@TESTE', '12', '12'),
(7, 'Ricardo Nonao', 'teste@teste.com', '123', '123'),
(8, 'Bruna', 'teste@teste.com', '12', '12'),
(9, 'Rafael', 'teste@teste.com', 'sd', 'sd'),
(10, 'Rafael', 'teste@teste.com', 'sd', 'sd'),
(11, 'Ricardo Nonato', 'ricardo@teste.com', '123', '123'),
(12, 'rafael', 'teste@teste.com', '12', '12'),
(13, 'Renata', 'renata@teste.com', '12', '12'),
(14, 'Flavio', 'fla@teste.com', 'qw', '12'),
(15, 'Renata', 'renata@teste.com', '12', '12'),
(16, 'Renata', 'novarenata@teste.com', '12', '12'),
(17, 'Tereza', 'tereza@teste', '123', '123'),
(18, 'Renata', 'ricardo@teste.com', 'qw', 'qw');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `colaboradores`
--
ALTER TABLE `colaboradores`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `colaboradores`
--
ALTER TABLE `colaboradores`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
